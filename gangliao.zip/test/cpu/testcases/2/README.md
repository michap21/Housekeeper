1. 8 virtual machines. 4 vcpu on pcpu 0 and 4 vcpu on pcpu 3. Each vcpu has same workload.
2. __Expected outcome__: balance to each pcpu.
