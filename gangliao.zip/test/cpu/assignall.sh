#!/bin/sh

cd ..
./assignfiletoallvm.py cpu/
