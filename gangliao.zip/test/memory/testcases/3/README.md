### A comprehensice test

1. All virtual machines start from 512MB.
2. All consumes memory.
3. A, B start freeing memory, while at the same time (C, D) continue consuming memory.
4. __Expected outcome__: memory resource moves from A, B to C, D.
